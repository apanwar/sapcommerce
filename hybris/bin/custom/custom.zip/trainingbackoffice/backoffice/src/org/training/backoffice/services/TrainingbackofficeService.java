/*
 * Copyright (c) 2020 SAP SE or an SAP affiliate company. All rights reserved
 */
package org.training.backoffice.services;

/**
 * Hello World TrainingbackofficeService
 */
public class TrainingbackofficeService
{
	public String getHello()
	{
		return "Hello";
	}
}
