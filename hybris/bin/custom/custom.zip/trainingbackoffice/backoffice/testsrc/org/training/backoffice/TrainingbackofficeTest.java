/*
 * Copyright (c) 2020 SAP SE or an SAP affiliate company. All rights reserved
 */
package org.training.backoffice;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class TrainingbackofficeTest
{
	@Test
	public void testNothing()
	{
		assertTrue(true);
		assertFalse(false);
	}
}
