/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at 27-Oct-2021, 11:47:09 AM                    ---
 * ----------------------------------------------------------------
 */
package org.training.jalo;

import de.hybris.platform.directpersistence.annotation.SLDSafe;
import de.hybris.platform.jalo.Item;
import de.hybris.platform.jalo.Item.AttributeMode;
import de.hybris.platform.jalo.SessionContext;
import de.hybris.platform.jalo.enumeration.EnumerationValue;
import de.hybris.platform.jalo.product.Product;
import de.hybris.platform.jalo.type.ComposedType;
import de.hybris.platform.jalo.type.TypeManager;
import de.hybris.platform.jalo.user.Employee;
import de.hybris.platform.util.Utilities;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.training.constants.TrainingConstants;

/**
 * Generated class for type Car.
 */
@SLDSafe
@SuppressWarnings({"unused","cast"})
public class Car extends Product
{
	/** Qualifier of the <code>Car.kw</code> attribute **/
	public static final String KW = "kw";
	/** Qualifier of the <code>Car.fuelType</code> attribute **/
	public static final String FUELTYPE = "fuelType";
	/** Qualifier of the <code>Car.defaultMechanic</code> attribute **/
	public static final String DEFAULTMECHANIC = "defaultMechanic";
	/** Qualifier of the <code>Car.mechanics</code> attribute **/
	public static final String MECHANICS = "mechanics";
	/** Relation ordering override parameter constants for CarsToEmployeesRelation from ((training))*/
	protected static String CARSTOEMPLOYEESRELATION_SRC_ORDERED = "relation.CarsToEmployeesRelation.source.ordered";
	protected static String CARSTOEMPLOYEESRELATION_TGT_ORDERED = "relation.CarsToEmployeesRelation.target.ordered";
	/** Relation disable markmodifed parameter constants for CarsToEmployeesRelation from ((training))*/
	protected static String CARSTOEMPLOYEESRELATION_MARKMODIFIED = "relation.CarsToEmployeesRelation.markmodified";
	protected static final Map<String, AttributeMode> DEFAULT_INITIAL_ATTRIBUTES;
	static
	{
		final Map<String, AttributeMode> tmp = new HashMap<String, AttributeMode>(Product.DEFAULT_INITIAL_ATTRIBUTES);
		tmp.put(KW, AttributeMode.INITIAL);
		tmp.put(FUELTYPE, AttributeMode.INITIAL);
		tmp.put(DEFAULTMECHANIC, AttributeMode.INITIAL);
		DEFAULT_INITIAL_ATTRIBUTES = Collections.unmodifiableMap(tmp);
	}
	@Override
	protected Map<String, AttributeMode> getDefaultAttributeModes()
	{
		return DEFAULT_INITIAL_ATTRIBUTES;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Car.defaultMechanic</code> attribute.
	 * @return the defaultMechanic
	 */
	public Employee getDefaultMechanic(final SessionContext ctx)
	{
		return (Employee)getProperty( ctx, "defaultMechanic".intern());
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Car.defaultMechanic</code> attribute.
	 * @return the defaultMechanic
	 */
	public Employee getDefaultMechanic()
	{
		return getDefaultMechanic( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Car.defaultMechanic</code> attribute. 
	 * @param value the defaultMechanic
	 */
	public void setDefaultMechanic(final SessionContext ctx, final Employee value)
	{
		setProperty(ctx, "defaultMechanic".intern(),value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Car.defaultMechanic</code> attribute. 
	 * @param value the defaultMechanic
	 */
	public void setDefaultMechanic(final Employee value)
	{
		setDefaultMechanic( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Car.fuelType</code> attribute.
	 * @return the fuelType - Fuel type
	 */
	public EnumerationValue getFuelType(final SessionContext ctx)
	{
		return (EnumerationValue)getProperty( ctx, "fuelType".intern());
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Car.fuelType</code> attribute.
	 * @return the fuelType - Fuel type
	 */
	public EnumerationValue getFuelType()
	{
		return getFuelType( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Car.fuelType</code> attribute. 
	 * @param value the fuelType - Fuel type
	 */
	public void setFuelType(final SessionContext ctx, final EnumerationValue value)
	{
		setProperty(ctx, "fuelType".intern(),value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Car.fuelType</code> attribute. 
	 * @param value the fuelType - Fuel type
	 */
	public void setFuelType(final EnumerationValue value)
	{
		setFuelType( getSession().getSessionContext(), value );
	}
	
	/**
	 * @deprecated since 2011, use {@link Utilities#getMarkModifiedOverride(de.hybris.platform.jalo.type.RelationType)
	 */
	@Override
	@Deprecated(since = "2105", forRemoval = true)
	public boolean isMarkModifiedDisabled(final Item referencedItem)
	{
		ComposedType relationSecondEnd0 = TypeManager.getInstance().getComposedType("Employee");
		if(relationSecondEnd0.isAssignableFrom(referencedItem.getComposedType()))
		{
			return Utilities.getMarkModifiedOverride(CARSTOEMPLOYEESRELATION_MARKMODIFIED);
		}
		return true;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Car.kw</code> attribute.
	 * @return the kw - Killo watt
	 */
	public Integer getKw(final SessionContext ctx)
	{
		return (Integer)getProperty( ctx, "kw".intern());
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Car.kw</code> attribute.
	 * @return the kw - Killo watt
	 */
	public Integer getKw()
	{
		return getKw( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Car.kw</code> attribute. 
	 * @return the kw - Killo watt
	 */
	public int getKwAsPrimitive(final SessionContext ctx)
	{
		Integer value = getKw( ctx );
		return value != null ? value.intValue() : 0;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Car.kw</code> attribute. 
	 * @return the kw - Killo watt
	 */
	public int getKwAsPrimitive()
	{
		return getKwAsPrimitive( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Car.kw</code> attribute. 
	 * @param value the kw - Killo watt
	 */
	public void setKw(final SessionContext ctx, final Integer value)
	{
		setProperty(ctx, "kw".intern(),value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Car.kw</code> attribute. 
	 * @param value the kw - Killo watt
	 */
	public void setKw(final Integer value)
	{
		setKw( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Car.kw</code> attribute. 
	 * @param value the kw - Killo watt
	 */
	public void setKw(final SessionContext ctx, final int value)
	{
		setKw( ctx,Integer.valueOf( value ) );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Car.kw</code> attribute. 
	 * @param value the kw - Killo watt
	 */
	public void setKw(final int value)
	{
		setKw( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Car.mechanics</code> attribute.
	 * @return the mechanics
	 */
	public Set<Employee> getMechanics(final SessionContext ctx)
	{
		final List<Employee> items = getLinkedItems( 
			ctx,
			true,
			TrainingConstants.Relations.CARSTOEMPLOYEESRELATION,
			"Employee",
			null,
			false,
			Utilities.getRelationOrderingOverride(CARSTOEMPLOYEESRELATION_TGT_ORDERED, true)
		);
		return new LinkedHashSet<Employee>(items);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Car.mechanics</code> attribute.
	 * @return the mechanics
	 */
	public Set<Employee> getMechanics()
	{
		return getMechanics( getSession().getSessionContext() );
	}
	
	public long getMechanicsCount(final SessionContext ctx)
	{
		return getLinkedItemsCount(
			ctx,
			true,
			TrainingConstants.Relations.CARSTOEMPLOYEESRELATION,
			"Employee",
			null
		);
	}
	
	public long getMechanicsCount()
	{
		return getMechanicsCount( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Car.mechanics</code> attribute. 
	 * @param value the mechanics
	 */
	public void setMechanics(final SessionContext ctx, final Set<Employee> value)
	{
		setLinkedItems( 
			ctx,
			true,
			TrainingConstants.Relations.CARSTOEMPLOYEESRELATION,
			null,
			value,
			false,
			Utilities.getRelationOrderingOverride(CARSTOEMPLOYEESRELATION_TGT_ORDERED, true),
			Utilities.getMarkModifiedOverride(CARSTOEMPLOYEESRELATION_MARKMODIFIED)
		);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Car.mechanics</code> attribute. 
	 * @param value the mechanics
	 */
	public void setMechanics(final Set<Employee> value)
	{
		setMechanics( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Adds <code>value</code> to mechanics. 
	 * @param value the item to add to mechanics
	 */
	public void addToMechanics(final SessionContext ctx, final Employee value)
	{
		addLinkedItems( 
			ctx,
			true,
			TrainingConstants.Relations.CARSTOEMPLOYEESRELATION,
			null,
			Collections.singletonList(value),
			false,
			Utilities.getRelationOrderingOverride(CARSTOEMPLOYEESRELATION_TGT_ORDERED, true),
			Utilities.getMarkModifiedOverride(CARSTOEMPLOYEESRELATION_MARKMODIFIED)
		);
	}
	
	/**
	 * <i>Generated method</i> - Adds <code>value</code> to mechanics. 
	 * @param value the item to add to mechanics
	 */
	public void addToMechanics(final Employee value)
	{
		addToMechanics( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Removes <code>value</code> from mechanics. 
	 * @param value the item to remove from mechanics
	 */
	public void removeFromMechanics(final SessionContext ctx, final Employee value)
	{
		removeLinkedItems( 
			ctx,
			true,
			TrainingConstants.Relations.CARSTOEMPLOYEESRELATION,
			null,
			Collections.singletonList(value),
			false,
			Utilities.getRelationOrderingOverride(CARSTOEMPLOYEESRELATION_TGT_ORDERED, true),
			Utilities.getMarkModifiedOverride(CARSTOEMPLOYEESRELATION_MARKMODIFIED)
		);
	}
	
	/**
	 * <i>Generated method</i> - Removes <code>value</code> from mechanics. 
	 * @param value the item to remove from mechanics
	 */
	public void removeFromMechanics(final Employee value)
	{
		removeFromMechanics( getSession().getSessionContext(), value );
	}
	
}
