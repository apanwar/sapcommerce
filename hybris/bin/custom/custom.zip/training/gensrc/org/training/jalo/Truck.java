/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at 27-Oct-2021, 11:47:09 AM                    ---
 * ----------------------------------------------------------------
 */
package org.training.jalo;

import de.hybris.platform.directpersistence.annotation.SLDSafe;
import de.hybris.platform.jalo.Item.AttributeMode;
import de.hybris.platform.jalo.SessionContext;
import de.hybris.platform.jalo.product.Product;
import de.hybris.platform.jalo.user.Employee;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * Generated class for type Truck.
 */
@SLDSafe
@SuppressWarnings({"unused","cast"})
public class Truck extends Product
{
	/** Qualifier of the <code>Truck.capacity</code> attribute **/
	public static final String CAPACITY = "capacity";
	/** Qualifier of the <code>Truck.drivers</code> attribute **/
	public static final String DRIVERS = "drivers";
	protected static final Map<String, AttributeMode> DEFAULT_INITIAL_ATTRIBUTES;
	static
	{
		final Map<String, AttributeMode> tmp = new HashMap<String, AttributeMode>(Product.DEFAULT_INITIAL_ATTRIBUTES);
		tmp.put(CAPACITY, AttributeMode.INITIAL);
		tmp.put(DRIVERS, AttributeMode.INITIAL);
		DEFAULT_INITIAL_ATTRIBUTES = Collections.unmodifiableMap(tmp);
	}
	@Override
	protected Map<String, AttributeMode> getDefaultAttributeModes()
	{
		return DEFAULT_INITIAL_ATTRIBUTES;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Truck.capacity</code> attribute.
	 * @return the capacity - Capacity in tons
	 */
	public Integer getCapacity(final SessionContext ctx)
	{
		return (Integer)getProperty( ctx, "capacity".intern());
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Truck.capacity</code> attribute.
	 * @return the capacity - Capacity in tons
	 */
	public Integer getCapacity()
	{
		return getCapacity( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Truck.capacity</code> attribute. 
	 * @return the capacity - Capacity in tons
	 */
	public int getCapacityAsPrimitive(final SessionContext ctx)
	{
		Integer value = getCapacity( ctx );
		return value != null ? value.intValue() : 0;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Truck.capacity</code> attribute. 
	 * @return the capacity - Capacity in tons
	 */
	public int getCapacityAsPrimitive()
	{
		return getCapacityAsPrimitive( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Truck.capacity</code> attribute. 
	 * @param value the capacity - Capacity in tons
	 */
	public void setCapacity(final SessionContext ctx, final Integer value)
	{
		setProperty(ctx, "capacity".intern(),value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Truck.capacity</code> attribute. 
	 * @param value the capacity - Capacity in tons
	 */
	public void setCapacity(final Integer value)
	{
		setCapacity( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Truck.capacity</code> attribute. 
	 * @param value the capacity - Capacity in tons
	 */
	public void setCapacity(final SessionContext ctx, final int value)
	{
		setCapacity( ctx,Integer.valueOf( value ) );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Truck.capacity</code> attribute. 
	 * @param value the capacity - Capacity in tons
	 */
	public void setCapacity(final int value)
	{
		setCapacity( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Truck.drivers</code> attribute.
	 * @return the drivers
	 */
	public Set<Employee> getDrivers(final SessionContext ctx)
	{
		Set<Employee> coll = (Set<Employee>)getProperty( ctx, "drivers".intern());
		return coll != null ? coll : Collections.EMPTY_SET;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Truck.drivers</code> attribute.
	 * @return the drivers
	 */
	public Set<Employee> getDrivers()
	{
		return getDrivers( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Truck.drivers</code> attribute. 
	 * @param value the drivers
	 */
	public void setDrivers(final SessionContext ctx, final Set<Employee> value)
	{
		setProperty(ctx, "drivers".intern(),value == null || !value.isEmpty() ? value : null );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Truck.drivers</code> attribute. 
	 * @param value the drivers
	 */
	public void setDrivers(final Set<Employee> value)
	{
		setDrivers( getSession().getSessionContext(), value );
	}
	
}
