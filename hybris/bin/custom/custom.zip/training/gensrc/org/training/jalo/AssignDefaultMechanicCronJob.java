/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at 27-Oct-2021, 11:47:09 AM                    ---
 * ----------------------------------------------------------------
 */
package org.training.jalo;

import de.hybris.platform.cronjob.jalo.CronJob;
import de.hybris.platform.directpersistence.annotation.SLDSafe;
import de.hybris.platform.jalo.Item.AttributeMode;
import de.hybris.platform.jalo.SessionContext;
import de.hybris.platform.jalo.user.Employee;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/**
 * Generated class for type AssignDefaultMechanicCronJob.
 */
@SLDSafe
@SuppressWarnings({"unused","cast"})
public class AssignDefaultMechanicCronJob extends CronJob
{
	/** Qualifier of the <code>AssignDefaultMechanicCronJob.defaultMechanic</code> attribute **/
	public static final String DEFAULTMECHANIC = "defaultMechanic";
	protected static final Map<String, AttributeMode> DEFAULT_INITIAL_ATTRIBUTES;
	static
	{
		final Map<String, AttributeMode> tmp = new HashMap<String, AttributeMode>(CronJob.DEFAULT_INITIAL_ATTRIBUTES);
		tmp.put(DEFAULTMECHANIC, AttributeMode.INITIAL);
		DEFAULT_INITIAL_ATTRIBUTES = Collections.unmodifiableMap(tmp);
	}
	@Override
	protected Map<String, AttributeMode> getDefaultAttributeModes()
	{
		return DEFAULT_INITIAL_ATTRIBUTES;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>AssignDefaultMechanicCronJob.defaultMechanic</code> attribute.
	 * @return the defaultMechanic
	 */
	public Employee getDefaultMechanic(final SessionContext ctx)
	{
		return (Employee)getProperty( ctx, "defaultMechanic".intern());
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>AssignDefaultMechanicCronJob.defaultMechanic</code> attribute.
	 * @return the defaultMechanic
	 */
	public Employee getDefaultMechanic()
	{
		return getDefaultMechanic( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>AssignDefaultMechanicCronJob.defaultMechanic</code> attribute. 
	 * @param value the defaultMechanic
	 */
	public void setDefaultMechanic(final SessionContext ctx, final Employee value)
	{
		setProperty(ctx, "defaultMechanic".intern(),value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>AssignDefaultMechanicCronJob.defaultMechanic</code> attribute. 
	 * @param value the defaultMechanic
	 */
	public void setDefaultMechanic(final Employee value)
	{
		setDefaultMechanic( getSession().getSessionContext(), value );
	}
	
}
