/*
 * Copyright (c) 2021 SAP SE or an SAP affiliate company. All rights reserved.
 */
package org.training.dao;

import de.hybris.bootstrap.annotations.IntegrationTest;
import de.hybris.platform.catalog.CatalogVersionService;
import de.hybris.platform.impex.jalo.ImpExException;
import de.hybris.platform.servicelayer.ServicelayerTransactionalTest;
import de.hybris.platform.servicelayer.i18n.CommonI18NService;

import java.util.List;

import javax.annotation.Resource;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.training.enums.FuelType;
import org.training.model.CarModel;

/**
 *
 */
@IntegrationTest
public class CarDaoIntegrationTest extends ServicelayerTransactionalTest
{

	@Resource
	private CarDao carDao;

	@Resource
	private CatalogVersionService catalogVersionService;

	@Resource
	private CommonI18NService commonI18NService;

	@Before
	public void setup() throws Exception
	{
		createCoreData();
		commonI18NService.setCurrentLanguage(commonI18NService.getLanguage("en"));
	}

	@Test
	public void testGetCarsForCode() throws ImpExException
	{
		importCsv("/training/test/CarDaoIntegrationTest.impex", "utf-8");

		final List<CarModel> cars = carDao.getCarsForCode("car0001");

		Assert.assertNotNull(cars);
		Assert.assertFalse(cars.isEmpty());
		Assert.assertTrue(cars.size() == 1);
		Assert.assertEquals("Audi A4", cars.get(0).getName());
	}

	@Test
	public void testGetCarsForCode_NotFound() throws ImpExException
	{
		importCsv("/training/test/CarDaoIntegrationTest.impex", "utf-8");

		final List<CarModel> cars = carDao.getCarsForCode("car0002");

		Assert.assertTrue(cars.isEmpty());
	}

	//	testGetCarsByChasisNumber_NotFound
	//	testGetCarsByChasisNumber
	@Test
	public void testGetCarsForChasisNumber() throws ImpExException
	{
		importCsv("/training/test/CarDaoIntegrationTest.impex", "utf-8");

		final CarModel cars = carDao.getCarsForChasisNumber("BNMBMBM54465");

		Assert.assertNotNull(cars);
		Assert.assertEquals("Audi A4", cars.getName());
	}

	@Test
	public void testGetCarsForChasisNumber_NotFound() throws ImpExException
	{
		importCsv("/training/test/CarDaoIntegrationTest.impex", "utf-8");

		final CarModel car = carDao.getCarsForChasisNumber("BNMBMBM54000");

		Assert.assertNull(car);
	}


	//	testGetCarByChasisNumberAndCatalogVersion_NotFound
	//	testGetCarByChasisNumberAndCatalogVersion
	@Test
	public void testGetCarForChasisCatalog() throws ImpExException
	{
		importCsv("/training/test/CarDaoIntegrationTest.impex", "utf-8");

		final CarModel cars = carDao.getCarsForChasisCatalog("BNMBMBM54465",
				catalogVersionService.getCatalogVersion("trainingCatalog", "Staged"));
		Assert.assertNotNull(cars);
		Assert.assertEquals("Audi A4", cars.getName());
	}

	@Test
	public void testGetCarsForChasisCatalog_NotFound() throws ImpExException
	{
		importCsv("/training/test/CarDaoIntegrationTest.impex", "utf-8");

		final CarModel car = carDao.getCarsForChasisCatalog("BNMBMBM54466",
				catalogVersionService.getCatalogVersion("trainingCatalog", "Staged"));

		Assert.assertNull(car);

	}


	//	testGetCarsByEngineNumber_NotFound
	//	testGetCarsByEngineNumber
	@Test
	public void testGetCarsForEngineNumber() throws ImpExException
	{
		importCsv("/training/test/CarDaoIntegrationTest.impex", "utf-8");

		final CarModel cars = carDao.getCarsForEngineNumber("JKGKJ87453");

		Assert.assertNotNull(cars);
		Assert.assertEquals("Audi A4", cars.getName());
	}

	@Test
	public void testGetCarsForEngineNumber_NotFound() throws ImpExException
	{
		importCsv("/training/test/CarDaoIntegrationTest.impex", "utf-8");

		final CarModel car = carDao.getCarsForEngineNumber("JKGKJ87473");

		Assert.assertNull(car);

	}

	//	testGetCarByEngineNumberAndCatalogVersion_NotFound
	//	testGetCarByEngineNumberAndCatalogVersion
	@Test
	public void testGetCarForEnfineCatalog() throws ImpExException
	{
		importCsv("/training/test/CarDaoIntegrationTest.impex", "utf-8");

		final CarModel cars = carDao.getCarsForEngineCatalog("JKGKJ87453",
				catalogVersionService.getCatalogVersion("trainingCatalog", "Staged"));
		Assert.assertNotNull(cars);
		Assert.assertEquals("Audi A4", cars.getName());
	}

	@Test
	public void testGetCarsForEngineCatalog_NotFound() throws ImpExException
	{
		importCsv("/training/test/CarDaoIntegrationTest.impex", "utf-8");

		final CarModel cars = carDao.getCarsForEngineCatalog("JKGKJ87900",
				catalogVersionService.getCatalogVersion("trainingCatalog", "Staged"));

		Assert.assertNull(cars);
	}

	//	testGetCarsByFuelType_NotFound
	//	testGetCarsByFuelType
	@Test
	public void testGetCarsForFuel() throws ImpExException
	{
		importCsv("/training/test/CarDaoIntegrationTest.impex", "utf-8");

		final List<CarModel> cars = carDao.getCarsForFuel(FuelType.GASOLINE);

		Assert.assertNotNull(cars);
		Assert.assertFalse(cars.isEmpty());
		Assert.assertEquals("Audi A4", cars.get(0).getName());
	}

	@Test
	public void testGetCarsForFuel_NotFound() throws ImpExException
	{
		importCsv("/training/test/CarDaoIntegrationTest.impex", "utf-8");

		final List<CarModel> cars = carDao.getCarsForFuel(FuelType.DIESEL);

		Assert.assertTrue(cars.isEmpty());
	}



	//	testGetCarsByFuelTypeAndCatalogVersion_NotFound
	//	testGetCarsByFuelTypeAndCatalogVersion
	@Test
	public void testGetCarsForFuelCatalog() throws ImpExException
	{
		importCsv("/training/test/CarDaoIntegrationTest.impex", "utf-8");

		final List<CarModel> cars = carDao.getCarsForFuelCatalog(FuelType.GASOLINE,
				catalogVersionService.getCatalogVersion("trainingCatalog", "Staged"));

		Assert.assertNotNull(cars);
		Assert.assertFalse(cars.isEmpty());
		Assert.assertEquals("Audi A4", cars.get(0).getName());
	}

	@Test
	public void testGetCarsForFuelCatalog_NotFound() throws ImpExException
	{
		importCsv("/training/test/CarDaoIntegrationTest.impex", "utf-8");

		final List<CarModel> cars = carDao.getCarsForFuelCatalog(FuelType.DIESEL,
				catalogVersionService.getCatalogVersion("trainingCatalog", "Staged"));

		Assert.assertTrue(cars.isEmpty());
	}



	//	testGetCarsByModelAndFuelType_NotFound
	//	testGetCarsByModelAndFuelType
	@Test
	public void testGetCarsForModelCatalog() throws ImpExException
	{
		importCsv("/training/test/CarDaoIntegrationTest.impex", "utf-8");

		final List<CarModel> cars = carDao.getCarsForModelCatalog("2010",
				catalogVersionService.getCatalogVersion("trainingCatalog", "Staged"));

		Assert.assertNotNull(cars);
		Assert.assertFalse(cars.isEmpty());
		Assert.assertEquals("Audi A4", cars.get(0).getName());
	}

	@Test
	public void testGetCarsForModelCatalog_NotFound() throws ImpExException
	{
		importCsv("/training/test/CarDaoIntegrationTest.impex", "utf-8");

		final List<CarModel> cars = carDao.getCarsForModelCatalog("2099",
				catalogVersionService.getCatalogVersion("trainingCatalog", "Staged"));

		Assert.assertNull(cars);
	}


	//	testGetCarsByModelAndFuelTypeAndCatalogVersion_NotFound
	//	testGetCarsByModelAndFuelTypeAndCatalogVersion
	@Test
	public void testGetCarsForModelFuelCatalog() throws ImpExException
	{
		importCsv("/training/test/CarDaoIntegrationTest.impex", "utf-8");

		final List<CarModel> cars = carDao.getCarsForModelFuelCatalog("2010", FuelType.GASOLINE,
				catalogVersionService.getCatalogVersion("trainingCatalog", "Staged"));

		Assert.assertNotNull(cars);
		Assert.assertFalse(cars.isEmpty());
		Assert.assertEquals("Audi A4", cars.get(0).getName());
	}

	@Test
	public void testCarsForModelFuelCatalog_NotFound() throws ImpExException
	{
		importCsv("/training/test/CarDaoIntegrationTest.impex", "utf-8");

		final List<CarModel> cars = carDao.getCarsForModelFuelCatalog("2099", FuelType.DIESEL,
				catalogVersionService.getCatalogVersion("trainingCatalog", "Staged"));

		Assert.assertTrue(cars.isEmpty());
	}

}
