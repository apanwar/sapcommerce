/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at Oct 25, 2021, 12:32:03 PM                   ---
 * ----------------------------------------------------------------
 */
package org.training.constants;

/**
 * @deprecated since ages - use constants in Model classes instead
 */
@Deprecated(since = "ages", forRemoval = false)
@SuppressWarnings({"unused","cast"})
public class GeneratedTrainingConstants
{
	public static final String EXTENSIONNAME = "training";
	public static class TC
	{
		public static final String CAR = "Car".intern();
		public static final String FUELTYPE = "FuelType".intern();
		public static final String TRUCK = "Truck".intern();
	}
	public static class Attributes
	{
		public static class Product
		{
			public static final String CHASISNUMBER = "chasisNumber".intern();
			public static final String ENGINENUMBER = "engineNumber".intern();
			public static final String MODEL = "model".intern();
		}
	}
	public static class Enumerations
	{
		public static class FuelType
		{
			public static final String GASOLINE = "gasoline".intern();
			public static final String DIESEL = "diesel".intern();
			public static final String ETHENOL = "ethenol".intern();
		}
	}
	public static class Relations
	{
		public static final String CARSTOEMPLOYEESRELATION = "CarsToEmployeesRelation".intern();
	}
	
	protected GeneratedTrainingConstants()
	{
		// private constructor
	}
	
	
}
