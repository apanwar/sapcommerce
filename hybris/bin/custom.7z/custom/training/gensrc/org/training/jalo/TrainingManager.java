/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at Oct 25, 2021, 12:32:03 PM                   ---
 * ----------------------------------------------------------------
 */
package org.training.jalo;

import de.hybris.platform.directpersistence.annotation.SLDSafe;
import de.hybris.platform.jalo.GenericItem;
import de.hybris.platform.jalo.Item;
import de.hybris.platform.jalo.Item.AttributeMode;
import de.hybris.platform.jalo.JaloBusinessException;
import de.hybris.platform.jalo.JaloSession;
import de.hybris.platform.jalo.JaloSystemException;
import de.hybris.platform.jalo.SessionContext;
import de.hybris.platform.jalo.extension.Extension;
import de.hybris.platform.jalo.extension.ExtensionManager;
import de.hybris.platform.jalo.link.Link;
import de.hybris.platform.jalo.product.Product;
import de.hybris.platform.jalo.type.ComposedType;
import de.hybris.platform.jalo.type.JaloGenericCreationException;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import org.training.constants.TrainingConstants;
import org.training.jalo.Car;
import org.training.jalo.Truck;

/**
 * Generated class for type <code>TrainingManager</code>.
 */
@SuppressWarnings({"unused","cast"})
@SLDSafe
public class TrainingManager extends Extension
{
	protected static final Map<String, Map<String, AttributeMode>> DEFAULT_INITIAL_ATTRIBUTES;
	static
	{
		final Map<String, Map<String, AttributeMode>> ttmp = new HashMap();
		Map<String, AttributeMode> tmp = new HashMap<String, AttributeMode>();
		tmp.put("engineNumber", AttributeMode.INITIAL);
		tmp.put("chasisNumber", AttributeMode.INITIAL);
		tmp.put("model", AttributeMode.INITIAL);
		ttmp.put("de.hybris.platform.jalo.product.Product", Collections.unmodifiableMap(tmp));
		DEFAULT_INITIAL_ATTRIBUTES = ttmp;
	}
	@Override
	public Map<String, AttributeMode> getDefaultAttributeModes(final Class<? extends Item> itemClass)
	{
		Map<String, AttributeMode> ret = new HashMap<>();
		final Map<String, AttributeMode> attr = DEFAULT_INITIAL_ATTRIBUTES.get(itemClass.getName());
		if (attr != null)
		{
			ret.putAll(attr);
		}
		return ret;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Product.chasisNumber</code> attribute.
	 * @return the chasisNumber
	 */
	public String getChasisNumber(final SessionContext ctx, final Product item)
	{
		return (String)item.getProperty( ctx, TrainingConstants.Attributes.Product.CHASISNUMBER);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Product.chasisNumber</code> attribute.
	 * @return the chasisNumber
	 */
	public String getChasisNumber(final Product item)
	{
		return getChasisNumber( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Product.chasisNumber</code> attribute. 
	 * @param value the chasisNumber
	 */
	public void setChasisNumber(final SessionContext ctx, final Product item, final String value)
	{
		item.setProperty(ctx, TrainingConstants.Attributes.Product.CHASISNUMBER,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Product.chasisNumber</code> attribute. 
	 * @param value the chasisNumber
	 */
	public void setChasisNumber(final Product item, final String value)
	{
		setChasisNumber( getSession().getSessionContext(), item, value );
	}
	
	public Car createCar(final SessionContext ctx, final Map attributeValues)
	{
		try
		{
			ComposedType type = getTenant().getJaloConnection().getTypeManager().getComposedType("Car");
			return (Car)type.newInstance( ctx, attributeValues );
		}
		catch( JaloGenericCreationException e)
		{
			final Throwable cause = e.getCause();
			throw (cause instanceof RuntimeException ?
			(RuntimeException)cause
			:
			new JaloSystemException( cause, cause.getMessage(), e.getErrorCode() ) );
		}
		catch( JaloBusinessException e )
		{
			throw new JaloSystemException( e ,"error creating Car : "+e.getMessage(), 0 );
		}
	}
	
	public Car createCar(final Map attributeValues)
	{
		return createCar( getSession().getSessionContext(), attributeValues );
	}
	
	public Truck createTruck(final SessionContext ctx, final Map attributeValues)
	{
		try
		{
			ComposedType type = getTenant().getJaloConnection().getTypeManager().getComposedType("Truck");
			return (Truck)type.newInstance( ctx, attributeValues );
		}
		catch( JaloGenericCreationException e)
		{
			final Throwable cause = e.getCause();
			throw (cause instanceof RuntimeException ?
			(RuntimeException)cause
			:
			new JaloSystemException( cause, cause.getMessage(), e.getErrorCode() ) );
		}
		catch( JaloBusinessException e )
		{
			throw new JaloSystemException( e ,"error creating Truck : "+e.getMessage(), 0 );
		}
	}
	
	public Truck createTruck(final Map attributeValues)
	{
		return createTruck( getSession().getSessionContext(), attributeValues );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Product.engineNumber</code> attribute.
	 * @return the engineNumber
	 */
	public String getEngineNumber(final SessionContext ctx, final Product item)
	{
		return (String)item.getProperty( ctx, TrainingConstants.Attributes.Product.ENGINENUMBER);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Product.engineNumber</code> attribute.
	 * @return the engineNumber
	 */
	public String getEngineNumber(final Product item)
	{
		return getEngineNumber( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Product.engineNumber</code> attribute. 
	 * @param value the engineNumber
	 */
	public void setEngineNumber(final SessionContext ctx, final Product item, final String value)
	{
		item.setProperty(ctx, TrainingConstants.Attributes.Product.ENGINENUMBER,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Product.engineNumber</code> attribute. 
	 * @param value the engineNumber
	 */
	public void setEngineNumber(final Product item, final String value)
	{
		setEngineNumber( getSession().getSessionContext(), item, value );
	}
	
	public static final TrainingManager getInstance()
	{
		ExtensionManager em = JaloSession.getCurrentSession().getExtensionManager();
		return (TrainingManager) em.getExtension(TrainingConstants.EXTENSIONNAME);
	}
	
	@Override
	public String getName()
	{
		return TrainingConstants.EXTENSIONNAME;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Product.model</code> attribute.
	 * @return the model
	 */
	public Integer getModel(final SessionContext ctx, final Product item)
	{
		return (Integer)item.getProperty( ctx, TrainingConstants.Attributes.Product.MODEL);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Product.model</code> attribute.
	 * @return the model
	 */
	public Integer getModel(final Product item)
	{
		return getModel( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Product.model</code> attribute. 
	 * @return the model
	 */
	public int getModelAsPrimitive(final SessionContext ctx, final Product item)
	{
		Integer value = getModel( ctx,item );
		return value != null ? value.intValue() : 0;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Product.model</code> attribute. 
	 * @return the model
	 */
	public int getModelAsPrimitive(final Product item)
	{
		return getModelAsPrimitive( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Product.model</code> attribute. 
	 * @param value the model
	 */
	public void setModel(final SessionContext ctx, final Product item, final Integer value)
	{
		item.setProperty(ctx, TrainingConstants.Attributes.Product.MODEL,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Product.model</code> attribute. 
	 * @param value the model
	 */
	public void setModel(final Product item, final Integer value)
	{
		setModel( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Product.model</code> attribute. 
	 * @param value the model
	 */
	public void setModel(final SessionContext ctx, final Product item, final int value)
	{
		setModel( ctx, item, Integer.valueOf( value ) );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Product.model</code> attribute. 
	 * @param value the model
	 */
	public void setModel(final Product item, final int value)
	{
		setModel( getSession().getSessionContext(), item, value );
	}
	
}
