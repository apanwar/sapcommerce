/*
 * Copyright (c) 2021 SAP SE or an SAP affiliate company. All rights reserved.
 */
package org.training.dao;

import de.hybris.platform.catalog.model.CatalogVersionModel;

import java.util.List;

import org.training.enums.FuelType;
import org.training.model.CarModel;


/**
 *
 */
public interface CarDao
{

	List<CarModel> getCarsForCode(String code);

	CarModel getCarForCode(String code, CatalogVersionModel catalogVersionModel);

	/**
	 * Search the cars by chasisNumber
	 */
	CarModel getCarsForChasisNumber(String chasisNumber);

	//	Search the cars by chasisNumber and catalogVersion
	CarModel getCarsForChasisCatalog(String string, CatalogVersionModel catalogVersion);

	//	Search the cars by engineNumber
	CarModel getCarsForEngineNumber(String engineNumber);

	//	Search the cars by engineNumber and catalogVersion
	CarModel getCarsForEngineCatalog(String string, CatalogVersionModel catalogVersion);

	//	Search the cars by fuelType
	List<CarModel> getCarsForFuel(FuelType fuel);

	//	Search the cars by fuelType and catalogVersion
	List<CarModel> getCarsForFuelCatalog(FuelType fuel, CatalogVersionModel catalogVersion);

	//	Search the cars by model and fuelType
	List<CarModel> getCarsForModelCatalog(String model, CatalogVersionModel catalogVersion);

	//	Search the cars by model, fuelType and catalogVersion
	List<CarModel> getCarsForModelFuelCatalog(String model, FuelType fuel, CatalogVersionModel catalogVersion);



}
