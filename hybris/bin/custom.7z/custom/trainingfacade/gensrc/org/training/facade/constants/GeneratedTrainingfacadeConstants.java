/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at Oct 25, 2021, 1:40:01 PM                    ---
 * ----------------------------------------------------------------
 */
package org.training.facade.constants;

/**
 * @deprecated since ages - use constants in Model classes instead
 */
@Deprecated(since = "ages", forRemoval = false)
@SuppressWarnings({"unused","cast"})
public class GeneratedTrainingfacadeConstants
{
	public static final String EXTENSIONNAME = "trainingfacade";
	
	protected GeneratedTrainingfacadeConstants()
	{
		// private constructor
	}
	
	
}
